// TRIGGER_PIN RB0 // Trigger pin for ultrasonic sensor
// ECHO_PIN RB1    // Echo pin for ultrasonic sensor
// BUZZER_PIN RB2  // Buzzer pin
// VIBRATION_PIN RB3  // Vibrator motor


unsigned int time=0;
unsigned distance=0;
unsigned int microseconds=0;
unsigned int i = 0;

void delay_us(microseconds) {
    for ( i = 0; i < microseconds; i++) {
        // busy loop
    }
}
void main() {
  // Set TRIGGER_PIN BUZZER_PIN ALSO VIBRATER as output pins

  TRISB = 0x02; // All ports are output except port RB1 is input

  // Set ECHO_PIN as an input pin


  while (1) {
    // Send a 10 microsecond pulse to the TRIGGER_PIN
    PORTB = 0x01;
    delay_us(10);
    PORTB = 0x00;


    // Wait for the ECHO_PIN to go high
    while(!(PORTB & 0x02));


    // Start timer
    TMR1H = 0;
    TMR1L = 0;
    T1CON = 0x01; // Enable timer with 1:1 prescaler

    // Wait for the ECHO_PIN to go low
    while(PORTB & 0x02);
;

    // Stop timer and calculate distance
    T1CON = 0x00; // Disable timer
    time = (TMR1H << 8);
   distance = (float)time / 58.82; // Distance in cm


    // Turn on buzzer if distance is 20 or less
    if (distance <= 3) {
      PORTB |= 0x04;
       delay_us(9990);
       PORTB &= ~0x04;

       PORTB |= 0x08;
       delay_us(9990);
        PORTB &= ~0x08;

    }
    else if (distance >3 && distance <=10){

         PORTB |= 0x04;
       delay_us(3550);
       PORTB &= ~0x04;

       PORTB |= 0x08;
       delay_us(6550);
        PORTB &= ~0x08;







    }
    else if (distance >10 && distance <=15){
      PORTB |= 0x04;
       delay_us(1550);
       PORTB &= ~0x04;

       PORTB |= 0x08;
       delay_us(3550);
        PORTB &= ~0x08;


    }
    else if (distance >15 && distance <=20){
      PORTB |= 0x04;
       delay_us(990);
       PORTB &= ~0x04;

       PORTB |= 0x08;
       delay_us(1990);
        PORTB &= ~0x08;

    }
     else{
       PORTB |= 0x04;
       delay_us(200);
       PORTB &= ~0x04;




  }





}
}